
context("silly test")


test_that("one equals one", {
    expect_equal(1,1)
})
