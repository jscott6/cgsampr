
library(testthat)
library(graphs)

test_check("graphs")
