loadModule("WeightedGraph", TRUE)
